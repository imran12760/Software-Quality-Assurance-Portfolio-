import type { Metadata } from 'next'
import { Mail, MapPin, Clock } from 'lucide-react'
import { PageShell, Section } from '@/components/page-shell'
import { ContactForm } from '@/components/contact-form'

export const metadata: Metadata = {
  title: 'Contact — WheelPik.pk',
  description:
    'Get in touch with the WheelPik.pk team for feedback, bug reports, new wheel category ideas, advertising or partnership enquiries.',
  alternates: { canonical: '/contact' },
}

export default function ContactPage() {
  return (
    <PageShell
      title="Contact us"
      intro="Feedback, a bug, a new category idea, or an advertising enquiry — send it over. We read every message and usually reply within two working days."
    >
      <Section heading="Reach us directly">
        <ul className="flex flex-col gap-3 not-italic">
          <li className="flex items-start gap-3">
            <Mail className="mt-0.5 size-4 shrink-0 text-accent" aria-hidden />
            <span>
              <span className="block text-foreground">Email</span>
              <a
                href="mailto:hello@wheelpik.pk"
                className="text-accent underline underline-offset-4"
              >
                hello@wheelpik.pk
              </a>
            </span>
          </li>
          <li className="flex items-start gap-3">
            <MapPin className="mt-0.5 size-4 shrink-0 text-accent" aria-hidden />
            <span>
              <span className="block text-foreground">Based in</span>
              Lahore, Punjab, Pakistan
            </span>
          </li>
          <li className="flex items-start gap-3">
            <Clock className="mt-0.5 size-4 shrink-0 text-accent" aria-hidden />
            <span>
              <span className="block text-foreground">Response time</span>
              Monday to Saturday, within 48 hours (PKT)
            </span>
          </li>
        </ul>
      </Section>

      <Section heading="Send a message">
        <p>
          Fill this in and it will open your email app with the message ready to send — no data is
          stored on our side.
        </p>
        <ContactForm />
      </Section>

      <Section heading="Advertising and partnerships">
        <p>
          For sponsorships, custom branded wheels for a campaign, or media enquiries, email us with
          &quot;Partnership&quot; in the subject line and include a little detail about your brand
          or audience.
        </p>
      </Section>
    </PageShell>
  )
}
