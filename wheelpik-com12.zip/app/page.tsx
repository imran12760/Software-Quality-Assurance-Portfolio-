'use client'

import { useMemo, useRef, useState } from 'react'
import { ArrowDown, Sparkles, Users } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Textarea } from '@/components/ui/textarea'
import { SpinWheel } from '@/components/spin-wheel'
import { ResultModal } from '@/components/result-modal'
import { AdSlot } from '@/components/ad-slot'
import { CATEGORIES, parseNames, type CategoryId } from '@/lib/situations'

export default function Page() {
  const [categoryId, setCategoryId] = useState<CategoryId>('friends')
  const [situation, setSituation] = useState(CATEGORIES[0].situations[0])
  const [customSituation, setCustomSituation] = useState('')
  const [rawNames, setRawNames] = useState('Ali, Ahmed, Usman, Bilal')
  const [rotation, setRotation] = useState(0)
  const [spinning, setSpinning] = useState(false)
  const [winner, setWinner] = useState<string | null>(null)
  const [modalOpen, setModalOpen] = useState(false)
  const pendingWinner = useRef<string | null>(null)

  const category = CATEGORIES.find((c) => c.id === categoryId) ?? CATEGORIES[0]
  const names = useMemo(() => parseNames(rawNames), [rawNames])
  const activeSituation = customSituation.trim() || situation
  const canSpin = names.length >= 2 && !spinning

  const selectCategory = (id: CategoryId) => {
    setCategoryId(id)
    const next = CATEGORIES.find((c) => c.id === id)
    if (next) setSituation(next.situations[0])
  }

  const spin = () => {
    if (!canSpin) return
    const slice = 360 / names.length
    const index = Math.floor(Math.random() * names.length)
    pendingWinner.current = names[index]

    // Land the chosen slice's centre under the top pointer.
    const targetAngle = 360 - (index * slice + slice / 2)
    const jitter = (Math.random() - 0.5) * slice * 0.6
    const current = ((rotation % 360) + 360) % 360
    const delta = ((targetAngle + jitter - current) % 360 + 360) % 360

    setSpinning(true)
    setRotation(rotation + 360 * 6 + delta)
  }

  const handleSpinEnd = () => {
    if (!spinning) return
    setSpinning(false)
    setWinner(pendingWinner.current)
    setModalOpen(true)
  }

  return (
    <main className="relative flex-1 overflow-hidden">
      <div
        aria-hidden
        className="pointer-events-none absolute inset-x-0 top-0 h-[420px] bg-[radial-gradient(60%_100%_at_50%_0%,oklch(0.62_0.24_300/0.35),transparent_70%)]"
      />

      <div className="relative mx-auto w-full max-w-5xl px-4 pb-16 pt-10 sm:px-6 sm:pt-14">
        <header className="text-center">
          <div className="inline-flex items-center gap-2 rounded-full border border-border bg-card/70 px-3 py-1 text-xs font-medium text-muted-foreground">
            <Sparkles className="size-3.5 text-accent" aria-hidden />
            Fair decisions, zero arguments
          </div>
          <h1 className="mt-4 text-4xl font-bold tracking-tight sm:text-6xl">
            <span className="bg-gradient-to-r from-primary via-accent to-primary bg-clip-text text-transparent">
              WheelPik
            </span>
            <span className="text-foreground">.pk</span>
          </h1>
          <p className="mx-auto mt-3 max-w-md text-balance text-sm text-muted-foreground sm:text-base">
            Pick fun situations &amp; decide instantly with friends!
          </p>
        </header>

        <div className="mt-10 grid gap-6 lg:grid-cols-[1fr_minmax(0,380px)] lg:items-start">
          {/* Controls */}
          <section className="rounded-3xl border border-border bg-card/70 p-5 backdrop-blur-sm sm:p-6">
            <h2 className="text-sm font-semibold uppercase tracking-[0.18em] text-muted-foreground">
              1. Pick a category
            </h2>
            <div className="mt-3 flex flex-wrap gap-2" role="tablist" aria-label="Categories">
              {CATEGORIES.map((c) => {
                const active = c.id === categoryId
                return (
                  <button
                    key={c.id}
                    type="button"
                    role="tab"
                    aria-selected={active}
                    onClick={() => selectCategory(c.id)}
                    className={`rounded-full border px-3.5 py-2 text-sm font-medium transition-all ${
                      active
                        ? 'border-transparent bg-primary text-primary-foreground shadow-[0_0_24px_-6px_oklch(0.62_0.24_300/0.9)]'
                        : 'border-border bg-secondary/50 text-muted-foreground hover:border-primary/50 hover:text-foreground'
                    }`}
                  >
                    <span aria-hidden>{c.emoji}</span> {c.label}
                  </button>
                )
              })}
            </div>

            <h2 className="mt-7 text-sm font-semibold uppercase tracking-[0.18em] text-muted-foreground">
              2. Choose the situation
            </h2>
            <div className="mt-3 grid gap-2 sm:grid-cols-2">
              {category.situations.map((s) => {
                const active = !customSituation.trim() && s === situation
                return (
                  <button
                    key={s}
                    type="button"
                    onClick={() => {
                      setSituation(s)
                      setCustomSituation('')
                    }}
                    className={`rounded-xl border px-3.5 py-3 text-left text-sm transition-all ${
                      active
                        ? 'border-accent/70 bg-accent/15 text-foreground'
                        : 'border-border bg-secondary/30 text-muted-foreground hover:border-accent/40 hover:text-foreground'
                    }`}
                  >
                    {s}
                  </button>
                )
              })}
            </div>

            <label
              htmlFor="custom-situation"
              className="mt-5 block text-xs font-medium text-muted-foreground"
            >
              Or write your own situation
            </label>
            <Input
              id="custom-situation"
              value={customSituation}
              onChange={(e) => setCustomSituation(e.target.value)}
              placeholder="e.g. Who explains this to the boss?"
              className="mt-2 h-11 rounded-xl"
            />

            <h2 className="mt-7 text-sm font-semibold uppercase tracking-[0.18em] text-muted-foreground">
              3. Add the names
            </h2>
            <Textarea
              aria-label="Names separated by commas"
              value={rawNames}
              onChange={(e) => setRawNames(e.target.value)}
              rows={3}
              placeholder="Ali, Ahmed, Usman, Bilal"
              className="mt-3 rounded-xl text-base"
            />
            <p className="mt-2 flex items-center gap-1.5 text-xs text-muted-foreground">
              <Users className="size-3.5" aria-hidden />
              {names.length} {names.length === 1 ? 'name' : 'names'} on the wheel
              {names.length < 2 && ' — add at least 2 to spin'}
            </p>

            <a
              href="#wheel"
              className="mt-5 flex items-center justify-center gap-1.5 rounded-xl border border-primary/40 bg-primary/10 px-3 py-2.5 text-sm font-medium text-foreground lg:hidden"
            >
              Wheel is ready below
              <ArrowDown className="size-4 text-accent" aria-hidden />
            </a>
          </section>

          {/* Wheel */}
          <section
            id="wheel"
            className="scroll-mt-20 rounded-3xl border border-border bg-card/70 p-5 backdrop-blur-sm sm:p-6"
          >
            <p className="mb-5 text-balance text-center text-sm font-medium text-foreground">
              {activeSituation}
            </p>

            <SpinWheel
              names={names}
              rotation={rotation}
              spinning={spinning}
              onTransitionEnd={handleSpinEnd}
            />

            <Button
              onClick={spin}
              disabled={!canSpin}
              className="mt-7 h-14 w-full rounded-2xl bg-gradient-to-r from-primary to-accent text-base font-semibold tracking-wide text-primary-foreground transition-transform hover:brightness-110 active:scale-[0.98]"
            >
              {spinning ? 'Spinning…' : 'SPIN THE WHEEL 🎡'}
            </Button>

            {winner && !modalOpen && !spinning && (
              <button
                type="button"
                onClick={() => setModalOpen(true)}
                className="mt-3 w-full text-center text-xs text-muted-foreground underline-offset-4 hover:underline"
              >
                Last result: {winner} — view &amp; share again
              </button>
            )}
          </section>
        </div>

        <AdSlot slot={process.env.NEXT_PUBLIC_ADSENSE_SLOT_HOME} className="mt-10" />

        <section className="mt-10 grid gap-3 sm:grid-cols-3">
          {[
            {
              title: 'No signup, no data',
              body: 'Names stay in your browser. Nothing is stored on a server.',
            },
            {
              title: 'Genuinely fair',
              body: 'Every name gets an equal chance on every single spin.',
            },
            {
              title: 'Share in one tap',
              body: 'Send the result straight to WhatsApp and end the argument.',
            },
          ].map((f) => (
            <div key={f.title} className="rounded-2xl border border-border bg-card/50 p-4">
              <h3 className="text-sm font-semibold text-foreground">{f.title}</h3>
              <p className="mt-1 text-xs leading-relaxed text-muted-foreground">{f.body}</p>
            </div>
          ))}
        </section>
      </div>

      <ResultModal
        open={modalOpen && !!winner}
        situation={activeSituation}
        winner={winner ?? ''}
        onClose={() => setModalOpen(false)}
        onSpinAgain={() => {
          setModalOpen(false)
          setTimeout(spin, 220)
        }}
      />
    </main>
  )
}
