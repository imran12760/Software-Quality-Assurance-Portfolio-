import type { MetadataRoute } from 'next'

export default function robots(): MetadataRoute.Robots {
  return {
    rules: [
      { userAgent: '*', allow: '/' },
      { userAgent: 'Mediapartners-Google', allow: '/' },
    ],
    sitemap: 'https://wheelpik.pk/sitemap.xml',
    host: 'https://wheelpik.pk',
  }
}
