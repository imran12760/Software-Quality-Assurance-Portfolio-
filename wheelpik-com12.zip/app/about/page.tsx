import type { Metadata } from 'next'
import Link from 'next/link'
import { PageShell, Section } from '@/components/page-shell'

export const metadata: Metadata = {
  title: 'About — WheelPik.pk',
  description:
    'WheelPik.pk is a free spin-the-wheel decision maker for friends, couples, offices and content creators. Learn who we are and how the wheel works.',
  alternates: { canonical: '/about' },
}

export default function AboutPage() {
  return (
    <PageShell
      title="About WheelPik.pk"
      intro="WheelPik.pk is a free, no-signup spinning wheel that settles everyday arguments in seconds — who pays the bill, who makes the tea, who explains it to the boss."
    >
      <Section heading="What we do">
        <p>
          Every group has that one decision nobody wants to make. WheelPik.pk turns it into a
          game: add the names, pick a situation, spin the wheel, and let the result do the
          talking. Nobody has to be the bad guy, and the loser usually laughs first.
        </p>
      </Section>

      <Section heading="How it works">
        <p>
          Choose a category — Friends, Couples, Office, Content Creators or Everyday — then pick
          one of the ready-made situations or type your own. Add two or more names, hit spin, and
          the wheel lands on one of them. You can share the result straight to WhatsApp or any
          other app on your phone.
        </p>
        <p>
          The result is picked with your browser&apos;s random number generator, so each name on
          the wheel has an equal chance every single spin. Nothing is weighted, and previous
          spins never affect the next one.
        </p>
      </Section>

      <Section heading="Built for Pakistan, useful everywhere">
        <p>
          The situations are written around everyday desi moments — chai runs, bill splitting,
          Careem bookings, group project presentations — but the wheel works for any group,
          anywhere in the world. Because you can type your own situation, it fits classrooms,
          hostels, offices and family WhatsApp groups equally well.
        </p>
      </Section>

      <Section heading="Privacy first">
        <p>
          There is no account, no login and no database. The names you type stay in your browser
          and are never sent to us. Read the{' '}
          <Link href="/privacy-policy" className="text-accent underline underline-offset-4">
            Privacy Policy
          </Link>{' '}
          for the full detail.
        </p>
      </Section>

      <Section heading="Say hello">
        <p>
          Ideas for new categories, a bug to report, or a partnership in mind? Head to the{' '}
          <Link href="/contact" className="text-accent underline underline-offset-4">
            Contact page
          </Link>{' '}
          and send us a message — we read everything.
        </p>
      </Section>
    </PageShell>
  )
}
