import type { Metadata } from 'next'
import Link from 'next/link'
import { PageShell, Section } from '@/components/page-shell'

export const metadata: Metadata = {
  title: 'Disclaimer — WheelPik.pk',
  description:
    'WheelPik.pk is an entertainment tool. Read our disclaimer covering randomness, no professional advice, external links and advertising.',
  alternates: { canonical: '/disclaimer' },
}

export default function DisclaimerPage() {
  return (
    <PageShell
      title="Disclaimer"
      intro="WheelPik.pk is built for fun. This page sets out the limits of what the site is and what it is not."
      updated="26 August 2026"
    >
      <Section heading="Entertainment purposes only">
        <p>
          The wheel exists to settle light, everyday decisions between friends, couples,
          colleagues and families. Results carry no authority. Nobody is obliged to act on a spin,
          and you should never use it to decide anything with legal, financial, medical or safety
          consequences.
        </p>
      </Section>

      <Section heading="No professional advice">
        <p>
          Nothing on this site is professional, legal, financial, medical or psychological advice.
          If a decision actually matters, consult a qualified professional instead of a wheel.
        </p>
      </Section>

      <Section heading="About the randomness">
        <p>
          Each spin uses your browser&apos;s random number generator, giving every name on the
          wheel an equal chance. It is not certified, audited or suitable for statistical research,
          cryptography, official draws or anything where verified randomness is required.
        </p>
      </Section>

      <Section heading="Accuracy of content">
        <p>
          We try to keep the site working correctly and its content accurate, but we make no
          warranty of completeness, accuracy or availability. The site is provided
          &quot;as is&quot;, and we are not liable for any loss arising from its use.
        </p>
      </Section>

      <Section heading="User-entered content">
        <p>
          Names and situations are typed by you and stay in your browser. We do not review,
          moderate or store them, and we are not responsible for what visitors choose to enter.
          Please use real people&apos;s names respectfully and with permission.
        </p>
      </Section>

      <Section heading="External links and advertising">
        <p>
          The site may contain third-party advertising and links to other websites, including
          WhatsApp when sharing a result. We do not control those services, do not endorse them,
          and are not responsible for their content or practices.
        </p>
      </Section>

      <Section heading="Fair use for creators">
        <p>
          Content creators are welcome to record, stream and screenshot the wheel for videos and
          posts. We simply ask that you do not present the site as your own product; a mention of
          WheelPik.pk is always appreciated.
        </p>
      </Section>

      <Section heading="Questions">
        <p>
          If anything here is unclear, read our{' '}
          <Link href="/terms" className="text-accent underline underline-offset-4">
            Terms &amp; Conditions
          </Link>{' '}
          or{' '}
          <Link href="/contact" className="text-accent underline underline-offset-4">
            get in touch
          </Link>
          .
        </p>
      </Section>
    </PageShell>
  )
}
