import type { MetadataRoute } from 'next'

const BASE_URL = 'https://wheelpik.pk'

export default function sitemap(): MetadataRoute.Sitemap {
  const now = new Date()
  const routes: Array<{ path: string; priority: number }> = [
    { path: '', priority: 1 },
    { path: '/about', priority: 0.7 },
    { path: '/contact', priority: 0.6 },
    { path: '/privacy-policy', priority: 0.5 },
    { path: '/terms', priority: 0.5 },
    { path: '/disclaimer', priority: 0.5 },
  ]

  return routes.map(({ path, priority }) => ({
    url: `${BASE_URL}${path}`,
    lastModified: now,
    changeFrequency: 'monthly',
    priority,
  }))
}
