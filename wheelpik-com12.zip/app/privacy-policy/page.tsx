import type { Metadata } from 'next'
import Link from 'next/link'
import { PageShell, Section } from '@/components/page-shell'

export const metadata: Metadata = {
  title: 'Privacy Policy — WheelPik.pk',
  description:
    'How WheelPik.pk handles your data: no accounts, no stored names, and clear information about cookies, analytics and third-party advertising.',
  alternates: { canonical: '/privacy-policy' },
}

export default function PrivacyPolicyPage() {
  return (
    <PageShell
      title="Privacy Policy"
      intro="This policy explains what information WheelPik.pk collects, how it is used, and the choices you have. By using the site you agree to this policy."
      updated="26 August 2026"
    >
      <Section heading="1. Who we are">
        <p>
          WheelPik.pk (&quot;we&quot;, &quot;us&quot;, &quot;the site&quot;) operates a free
          spin-the-wheel decision tool at wheelpik.pk. You can reach us any time through the{' '}
          <Link href="/contact" className="text-accent underline underline-offset-4">
            Contact page
          </Link>
          .
        </p>
      </Section>

      <Section heading="2. Information you enter">
        <p>
          The names and custom situations you type into the wheel are processed entirely inside
          your own browser. We do not transmit, store or log them on any server, and they
          disappear when you close or refresh the page. We never ask you to create an account.
        </p>
      </Section>

      <Section heading="3. Information collected automatically">
        <p>
          Like most websites, our hosting provider and analytics tooling automatically receive
          basic technical information when you visit: IP address, browser type and version,
          device type, referring page, pages viewed and timestamps. This is used in aggregate to
          understand traffic, fix errors and keep the site secure.
        </p>
      </Section>

      <Section heading="4. Cookies and similar technologies">
        <p>
          Cookies are small files stored on your device. WheelPik.pk uses them for essential site
          function, to measure aggregate usage, and — where advertising is enabled — to support
          ad delivery. You can block or delete cookies in your browser settings at any time;
          the wheel will keep working without them.
        </p>
      </Section>

      <Section heading="5. Advertising and Google AdSense">
        <p>
          We may display advertising served by third-party vendors, including Google. Third-party
          vendors, including Google, use cookies to serve ads based on a user&apos;s prior visits
          to this website or other websites.
        </p>
        <p>
          Google&apos;s use of advertising cookies enables it and its partners to serve ads to you
          based on your visit to our site and/or other sites on the internet. You may opt out of
          personalised advertising by visiting{' '}
          <a
            href="https://www.google.com/settings/ads"
            target="_blank"
            rel="noopener noreferrer"
            className="text-accent underline underline-offset-4"
          >
            Google Ads Settings
          </a>
          , or opt out of a third-party vendor&apos;s use of cookies for personalised advertising
          at{' '}
          <a
            href="https://www.aboutads.info/choices/"
            target="_blank"
            rel="noopener noreferrer"
            className="text-accent underline underline-offset-4"
          >
            aboutads.info
          </a>
          .
        </p>
        <p>
          Third-party ad networks may also place or read cookies and web beacons on your device.
          We do not control those technologies and their use is governed by their own privacy
          policies.
        </p>
      </Section>

      <Section heading="6. Analytics">
        <p>
          We use privacy-friendly, aggregate analytics to count page views and understand which
          categories people use most. These reports contain no names entered into the wheel and
          are not used to identify individual visitors.
        </p>
      </Section>

      <Section heading="7. Sharing your information">
        <p>
          We do not sell or rent personal information. Technical data may be processed by our
          hosting, analytics and advertising providers strictly to deliver the service, or
          disclosed where we are legally required to do so.
        </p>
      </Section>

      <Section heading="8. Children’s privacy">
        <p>
          WheelPik.pk is intended for a general audience and is not directed at children under 13.
          We do not knowingly collect personal information from children. If you believe a child
          has provided us information, contact us and we will remove it.
        </p>
      </Section>

      <Section heading="9. Your rights and choices">
        <p>
          Because we do not hold accounts or stored personal profiles, there is normally nothing
          for us to export or delete. You can still clear cookies, use your browser&apos;s
          do-not-track and ad-blocking features, or contact us with any privacy request and we
          will respond as required by applicable law.
        </p>
      </Section>

      <Section heading="10. Data security">
        <p>
          The site is served over HTTPS and we apply reasonable technical safeguards. No method of
          transmission over the internet is completely secure, so we cannot guarantee absolute
          security.
        </p>
      </Section>

      <Section heading="11. External links">
        <p>
          Pages may link to other websites, such as WhatsApp when you share a result. We are not
          responsible for the content or privacy practices of those sites.
        </p>
      </Section>

      <Section heading="12. Changes to this policy">
        <p>
          We may update this policy as the site evolves. The revised version will be posted on
          this page with a new &quot;last updated&quot; date, and continued use of the site means
          you accept the changes.
        </p>
      </Section>

      <Section heading="13. Contact">
        <p>
          Questions about this policy? Write to us at{' '}
          <a
            href="mailto:hello@wheelpik.pk"
            className="text-accent underline underline-offset-4"
          >
            hello@wheelpik.pk
          </a>
          .
        </p>
      </Section>
    </PageShell>
  )
}
