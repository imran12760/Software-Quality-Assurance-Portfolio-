import type { Metadata } from 'next'
import Link from 'next/link'
import { PageShell, Section } from '@/components/page-shell'

export const metadata: Metadata = {
  title: 'Terms & Conditions — WheelPik.pk',
  description:
    'The terms that govern your use of WheelPik.pk, including acceptable use, intellectual property, advertising and limitation of liability.',
  alternates: { canonical: '/terms' },
}

export default function TermsPage() {
  return (
    <PageShell
      title="Terms & Conditions"
      intro="These terms are an agreement between you and WheelPik.pk. By visiting or using the site you accept them in full. If you do not agree, please stop using the site."
      updated="26 August 2026"
    >
      <Section heading="1. The service">
        <p>
          WheelPik.pk provides a free, browser-based spinning wheel that randomly selects one name
          from a list you enter. It is offered for entertainment and convenience only, with no
          account required.
        </p>
      </Section>

      <Section heading="2. Acceptable use">
        <p>You agree not to use the site to:</p>
        <ul className="flex list-disc flex-col gap-1 pl-5">
          <li>harass, bully, defame or target any person or group;</li>
          <li>enter names or text that are unlawful, hateful, obscene or infringing;</li>
          <li>run gambling, betting or any activity involving money or prizes;</li>
          <li>
            scrape, overload, reverse engineer, or attempt to bypass the security of the site;
          </li>
          <li>republish the site as your own product or service.</li>
        </ul>
        <p>
          You are responsible for the names and situations you type in and for having permission
          to use other people&apos;s names.
        </p>
      </Section>

      <Section heading="3. No gambling or wagering">
        <p>
          The wheel must not be used for any form of gambling, lottery, betting or prize draw
          where money or anything of value is at stake. WheelPik.pk is a game for settling
          everyday decisions, nothing more.
        </p>
      </Section>

      <Section heading="4. Randomness">
        <p>
          Results are generated using your browser&apos;s built-in random number generator. While
          each name has an equal chance on every spin, we make no warranty that the output is
          suitable for scientific, statistical, cryptographic or official purposes.
        </p>
      </Section>

      <Section heading="5. Intellectual property">
        <p>
          The WheelPik.pk name, design, wheel interface, written situations and code are owned by
          us and protected by applicable law. You may use the site as intended, but you may not
          copy, sell or redistribute substantial parts of it without written permission. Screen
          recordings and screenshots for social content are welcome — a credit to WheelPik.pk is
          appreciated.
        </p>
      </Section>

      <Section heading="6. Advertising and third-party content">
        <p>
          The site may display third-party advertising and links. We do not endorse advertisers or
          linked sites and are not responsible for their content, products or practices. Your
          dealings with them are solely between you and them.
        </p>
      </Section>

      <Section heading="7. Availability">
        <p>
          The site is provided &quot;as is&quot; and &quot;as available&quot;. We may change,
          suspend or discontinue any part of it at any time without notice, and we do not
          guarantee uninterrupted or error-free operation.
        </p>
      </Section>

      <Section heading="8. Limitation of liability">
        <p>
          To the maximum extent permitted by law, WheelPik.pk is not liable for any indirect,
          incidental or consequential loss, or for any decision, dispute, expense or outcome
          arising from a spin result. Every decision you act on remains your own.
        </p>
      </Section>

      <Section heading="9. Privacy">
        <p>
          Use of the site is also governed by our{' '}
          <Link href="/privacy-policy" className="text-accent underline underline-offset-4">
            Privacy Policy
          </Link>{' '}
          and{' '}
          <Link href="/disclaimer" className="text-accent underline underline-offset-4">
            Disclaimer
          </Link>
          .
        </p>
      </Section>

      <Section heading="10. Governing law">
        <p>
          These terms are governed by the laws of the Islamic Republic of Pakistan, and the courts
          of Pakistan have exclusive jurisdiction over any dispute relating to them.
        </p>
      </Section>

      <Section heading="11. Updates">
        <p>
          We may revise these terms from time to time. The current version is always the one
          published on this page, and continued use of the site after a change means you accept
          the updated terms.
        </p>
      </Section>

      <Section heading="12. Contact">
        <p>
          For anything related to these terms, email{' '}
          <a href="mailto:hello@wheelpik.pk" className="text-accent underline underline-offset-4">
            hello@wheelpik.pk
          </a>
          .
        </p>
      </Section>
    </PageShell>
  )
}
