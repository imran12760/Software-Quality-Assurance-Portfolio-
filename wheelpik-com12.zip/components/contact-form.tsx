'use client'

import { useState } from 'react'
import { Send } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Textarea } from '@/components/ui/textarea'

export function ContactForm() {
  const [name, setName] = useState('')
  const [email, setEmail] = useState('')
  const [message, setMessage] = useState('')

  const ready = name.trim() && email.trim() && message.trim()

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    if (!ready) return
    const subject = encodeURIComponent(`WheelPik.pk message from ${name.trim()}`)
    const body = encodeURIComponent(
      `${message.trim()}\n\n—\nName: ${name.trim()}\nEmail: ${email.trim()}`,
    )
    window.location.href = `mailto:hello@wheelpik.pk?subject=${subject}&body=${body}`
  }

  return (
    <form onSubmit={handleSubmit} className="mt-2 flex flex-col gap-4">
      <div className="grid gap-4 sm:grid-cols-2">
        <div className="flex flex-col gap-2">
          <label htmlFor="contact-name" className="text-xs font-medium text-muted-foreground">
            Your name
          </label>
          <Input
            id="contact-name"
            value={name}
            onChange={(e) => setName(e.target.value)}
            placeholder="Ali Raza"
            autoComplete="name"
            className="h-11 rounded-xl"
          />
        </div>
        <div className="flex flex-col gap-2">
          <label htmlFor="contact-email" className="text-xs font-medium text-muted-foreground">
            Your email
          </label>
          <Input
            id="contact-email"
            type="email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            placeholder="you@example.com"
            autoComplete="email"
            className="h-11 rounded-xl"
          />
        </div>
      </div>

      <div className="flex flex-col gap-2">
        <label htmlFor="contact-message" className="text-xs font-medium text-muted-foreground">
          Message
        </label>
        <Textarea
          id="contact-message"
          value={message}
          onChange={(e) => setMessage(e.target.value)}
          rows={5}
          placeholder="Tell us what's on your mind…"
          className="rounded-xl text-base"
        />
      </div>

      <Button
        type="submit"
        disabled={!ready}
        className="h-12 w-full rounded-2xl bg-gradient-to-r from-primary to-accent font-semibold text-primary-foreground transition-transform hover:brightness-110 active:scale-[0.99] sm:w-auto sm:px-8"
      >
        <Send className="size-4" aria-hidden />
        Open in email app
      </Button>
    </form>
  )
}
