'use client'

import { useEffect, useMemo } from 'react'
import { PartyPopper, Share2, X } from 'lucide-react'
import { Button } from '@/components/ui/button'

const CONFETTI_COLORS = [
  'var(--wheel-1)',
  'var(--wheel-2)',
  'var(--wheel-3)',
  'var(--wheel-4)',
]

function Confetti() {
  const pieces = useMemo(
    () =>
      Array.from({ length: 40 }, (_, i) => ({
        id: i,
        left: Math.random() * 100,
        drift: `${Math.round((Math.random() - 0.5) * 160)}px`,
        delay: `${Math.random() * 0.7}s`,
        color: CONFETTI_COLORS[i % CONFETTI_COLORS.length],
        size: 6 + Math.round(Math.random() * 6),
      })),
    [],
  )

  return (
    <div aria-hidden className="pointer-events-none absolute inset-0 overflow-hidden">
      {pieces.map((p) => (
        <span
          key={p.id}
          className="animate-confetti absolute top-0 rounded-[2px]"
          style={{
            left: `${p.left}%`,
            width: p.size,
            height: p.size * 1.6,
            background: p.color,
            animationDelay: p.delay,
            ['--drift' as string]: p.drift,
          }}
        />
      ))}
    </div>
  )
}

export function ResultModal({
  open,
  situation,
  winner,
  onClose,
  onSpinAgain,
}: {
  open: boolean
  situation: string
  winner: string
  onClose: () => void
  onSpinAgain: () => void
}) {
  useEffect(() => {
    if (!open) return
    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose()
    }
    window.addEventListener('keydown', onKey)
    return () => window.removeEventListener('keydown', onKey)
  }, [open, onClose])

  if (!open) return null

  const shareText = `${situation}\n\n🏆 ${winner} — decided by the wheel!\n\nPowered by WheelPik.pk`

  const share = async () => {
    if (typeof navigator !== 'undefined' && navigator.share) {
      try {
        await navigator.share({ title: 'WheelPik.pk', text: shareText })
        return
      } catch {
        // user cancelled or share unavailable — fall through to WhatsApp
      }
    }
    window.open(
      `https://wa.me/?text=${encodeURIComponent(shareText)}`,
      '_blank',
      'noopener,noreferrer',
    )
  }

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      <button
        type="button"
        aria-label="Close result"
        onClick={onClose}
        className="absolute inset-0 cursor-default bg-background/80 backdrop-blur-sm"
      />

      <div
        role="dialog"
        aria-modal="true"
        aria-labelledby="result-title"
        className="animate-winner-pop relative w-full max-w-md overflow-hidden rounded-3xl border border-border bg-card p-6 text-center shadow-[0_0_80px_-20px_oklch(0.62_0.24_300/0.9)] sm:p-8"
      >
        <Confetti />

        <div className="relative">
          <div className="flex items-center justify-center gap-2 text-xs font-semibold uppercase tracking-[0.2em] text-muted-foreground">
            <PartyPopper className="size-4 text-accent" aria-hidden />
            The wheel has spoken
          </div>

          <p id="result-title" className="mt-4 text-balance text-base text-muted-foreground">
            {situation}
          </p>

          <p className="mt-3 text-pretty text-4xl font-bold leading-tight text-foreground sm:text-5xl">
            {winner}
          </p>

          <div className="mx-auto mt-5 h-px w-24 bg-gradient-to-r from-transparent via-accent to-transparent" />

          <p className="mt-4 text-sm text-muted-foreground">
            Powered by{' '}
            <span className="font-semibold text-foreground">WheelPik.pk</span>
          </p>

          <div className="mt-6 flex flex-col gap-3">
            <Button onClick={share} className="h-12 w-full rounded-xl text-base">
              <Share2 className="size-4" aria-hidden />
              Share on WhatsApp 📱
            </Button>
            <div className="flex gap-3">
              <Button
                onClick={onSpinAgain}
                variant="secondary"
                className="h-11 flex-1 rounded-xl"
              >
                Spin again
              </Button>
              <Button onClick={onClose} variant="outline" className="h-11 flex-1 rounded-xl">
                <X className="size-4" aria-hidden />
                Close
              </Button>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
