'use client'

import { useEffect, useRef } from 'react'

type AdFormat = 'leaderboard' | 'in-article' | 'square'

const MIN_HEIGHT: Record<AdFormat, string> = {
  leaderboard: 'min-h-[100px] sm:min-h-[90px]',
  'in-article': 'min-h-[250px]',
  square: 'min-h-[250px]',
}

/**
 * Reserved advertising space.
 *
 * Renders a real AdSense unit when NEXT_PUBLIC_ADSENSE_CLIENT is configured and a
 * slot id is supplied, otherwise it keeps the exact same space reserved so the
 * layout never shifts once ads go live.
 */
export function AdSlot({
  slot,
  format = 'leaderboard',
  label = 'Advertisement',
  className = '',
}: {
  slot?: string
  format?: AdFormat
  label?: string
  className?: string
}) {
  const client = process.env.NEXT_PUBLIC_ADSENSE_CLIENT
  const live = Boolean(client && slot)
  const pushed = useRef(false)

  useEffect(() => {
    if (!live || pushed.current) return
    pushed.current = true
    try {
      // @ts-expect-error injected by the AdSense script
      ;(window.adsbygoogle = window.adsbygoogle || []).push({})
    } catch {
      // AdSense script not ready yet — the unit fills on the next page view.
    }
  }, [live])

  return (
    <aside
      aria-label={label}
      className={`w-full overflow-hidden rounded-2xl border border-dashed border-border/70 bg-card/30 p-2 ${className}`}
    >
      <p className="mb-1.5 text-center text-[10px] uppercase tracking-[0.22em] text-muted-foreground/70">
        {label}
      </p>
      {live ? (
        <ins
          className="adsbygoogle block"
          style={{ display: 'block' }}
          data-ad-client={client}
          data-ad-slot={slot}
          data-ad-format={format === 'in-article' ? 'fluid' : 'auto'}
          data-full-width-responsive="true"
        />
      ) : (
        <div
          className={`flex items-center justify-center rounded-xl bg-secondary/25 ${MIN_HEIGHT[format]}`}
        >
          <span className="px-3 text-center text-[11px] leading-relaxed text-muted-foreground/60">
            Ad space reserved
          </span>
        </div>
      )}
    </aside>
  )
}
