import type { ReactNode } from 'react'
import { AdSlot } from '@/components/ad-slot'

export function PageShell({
  title,
  intro,
  updated,
  children,
}: {
  title: string
  intro?: string
  updated?: string
  children: ReactNode
}) {
  return (
    <main className="relative flex-1 overflow-hidden">
      <div
        aria-hidden
        className="pointer-events-none absolute inset-x-0 top-0 h-[280px] bg-[radial-gradient(60%_100%_at_50%_0%,oklch(0.62_0.24_300/0.28),transparent_70%)]"
      />
      <div className="relative mx-auto w-full max-w-3xl px-4 pb-16 pt-10 sm:px-6 sm:pt-14">
        <h1 className="text-3xl font-bold tracking-tight text-balance sm:text-4xl">{title}</h1>
        {intro && (
          <p className="mt-3 text-pretty leading-relaxed text-muted-foreground">{intro}</p>
        )}
        {updated && (
          <p className="mt-3 text-xs uppercase tracking-[0.18em] text-muted-foreground">
            Last updated: {updated}
          </p>
        )}
        <div className="mt-8 flex flex-col gap-6 rounded-3xl border border-border bg-card/70 p-5 leading-relaxed backdrop-blur-sm sm:p-7">
          {children}
        </div>

        <AdSlot
          slot={process.env.NEXT_PUBLIC_ADSENSE_SLOT_CONTENT}
          format="in-article"
          className="mt-8"
        />
      </div>
    </main>
  )
}

export function Section({ heading, children }: { heading: string; children: ReactNode }) {
  return (
    <section className="flex flex-col gap-2">
      <h2 className="text-base font-semibold text-foreground sm:text-lg">{heading}</h2>
      <div className="flex flex-col gap-2 text-sm leading-relaxed text-muted-foreground sm:text-base">
        {children}
      </div>
    </section>
  )
}
