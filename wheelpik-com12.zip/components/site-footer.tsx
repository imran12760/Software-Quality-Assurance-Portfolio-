import Link from 'next/link'

export function SiteFooter() {
  return (
    <footer className="mt-auto border-t border-border/70 bg-card/40">
      <div className="mx-auto flex w-full max-w-5xl flex-col gap-4 px-4 py-8 sm:px-6 md:flex-row md:items-center md:justify-between">
        <div>
          <p className="text-sm font-semibold">
            <span className="bg-gradient-to-r from-primary via-accent to-primary bg-clip-text text-transparent">
              WheelPik
            </span>
            <span className="text-foreground">.pk</span>
          </p>
          <p className="mt-1 text-xs text-muted-foreground">
            Fair decisions, zero arguments. Made in Pakistan.
          </p>
        </div>

        <nav aria-label="Footer" className="flex flex-wrap gap-x-4 gap-y-2 text-xs">
          <Link href="/about" className="text-muted-foreground hover:text-foreground">
            About
          </Link>
          <Link href="/contact" className="text-muted-foreground hover:text-foreground">
            Contact
          </Link>
          <Link href="/privacy-policy" className="text-muted-foreground hover:text-foreground">
            Privacy Policy
          </Link>
          <Link href="/terms" className="text-muted-foreground hover:text-foreground">
            Terms &amp; Conditions
          </Link>
          <Link href="/disclaimer" className="text-muted-foreground hover:text-foreground">
            Disclaimer
          </Link>
        </nav>
      </div>
      <div className="border-t border-border/70 px-4 py-4 text-center text-xs text-muted-foreground sm:px-6">
        &copy; {new Date().getFullYear()} WheelPik.pk — All rights reserved.
      </div>
    </footer>
  )
}
