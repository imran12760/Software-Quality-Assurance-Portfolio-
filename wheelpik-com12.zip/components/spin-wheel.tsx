'use client'

const SIZE = 320
const R = SIZE / 2
const CENTER = R
const FILLS = [
  'var(--wheel-1)',
  'var(--wheel-2)',
  'var(--wheel-3)',
  'var(--wheel-4)',
  'var(--wheel-5)',
]

function polar(radius: number, angleDeg: number) {
  const a = ((angleDeg - 90) * Math.PI) / 180
  return { x: CENTER + radius * Math.cos(a), y: CENTER + radius * Math.sin(a) }
}

function segmentPath(start: number, end: number) {
  const p1 = polar(R - 4, start)
  const p2 = polar(R - 4, end)
  const largeArc = end - start > 180 ? 1 : 0
  return `M ${CENTER} ${CENTER} L ${p1.x.toFixed(2)} ${p1.y.toFixed(2)} A ${R - 4} ${R - 4} 0 ${largeArc} 1 ${p2.x.toFixed(2)} ${p2.y.toFixed(2)} Z`
}

function fillFor(index: number, total: number) {
  // Avoid the first and last slice sharing a colour on odd counts.
  if (index === total - 1 && total > 1 && index % FILLS.length === 0) {
    return FILLS[1]
  }
  return FILLS[index % FILLS.length]
}

export function SpinWheel({
  names,
  rotation,
  spinning,
  onTransitionEnd,
}: {
  names: string[]
  rotation: number
  spinning: boolean
  onTransitionEnd: () => void
}) {
  const total = names.length
  const slice = total > 0 ? 360 / total : 360

  return (
    <div className="relative mx-auto w-full max-w-[340px]">
      {/* Pointer */}
      <div className="absolute left-1/2 top-0 z-20 -translate-x-1/2 -translate-y-1">
        <div className="h-0 w-0 border-x-[12px] border-t-[20px] border-x-transparent border-t-accent drop-shadow-[0_2px_8px_oklch(0.68_0.23_350/0.6)]" />
      </div>

      <div className="rounded-full border border-border/80 bg-card/60 p-3 shadow-[0_0_60px_-15px_oklch(0.62_0.24_300/0.7)]">
        <svg
          viewBox={`0 0 ${SIZE} ${SIZE}`}
          className="h-auto w-full"
          role="img"
          aria-label={
            total > 0 ? `Wheel with ${total} names: ${names.join(', ')}` : 'Empty wheel'
          }
          style={{
            transform: `rotate(${rotation}deg)`,
            transition: spinning
              ? 'transform 4.2s cubic-bezier(0.12, 0.72, 0.06, 1)'
              : 'none',
          }}
          onTransitionEnd={onTransitionEnd}
        >
          {total === 0 ? (
            <circle cx={CENTER} cy={CENTER} r={R - 4} fill="var(--muted)" />
          ) : total === 1 ? (
            <circle cx={CENTER} cy={CENTER} r={R - 4} fill={FILLS[0]} />
          ) : (
            names.map((name, i) => (
              <path
                key={`${name}-${i}`}
                d={segmentPath(i * slice, (i + 1) * slice)}
                fill={fillFor(i, total)}
                stroke="oklch(1 0 0 / 20%)"
                strokeWidth="1"
              />
            ))
          )}

          {names.map((name, i) => {
            const mid = i * slice + slice / 2
            const pos = polar(R * 0.62, mid)
            return (
              <text
                key={`label-${name}-${i}`}
                x={pos.x}
                y={pos.y}
                fill="var(--wheel-label)"
                fontSize={total > 10 ? 11 : total > 7 ? 13 : 15}
                fontWeight="600"
                textAnchor="middle"
                dominantBaseline="middle"
                transform={`rotate(${mid} ${pos.x} ${pos.y})`}
              >
                {name.length > 12 ? `${name.slice(0, 11)}…` : name}
              </text>
            )
          })}
        </svg>
      </div>

      {/* Hub */}
      <div className="pointer-events-none absolute left-1/2 top-1/2 z-10 flex size-14 -translate-x-1/2 -translate-y-1/2 items-center justify-center rounded-full border border-border bg-card text-xl">
        🎡
      </div>
    </div>
  )
}
