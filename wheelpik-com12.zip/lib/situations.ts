export type CategoryId = 'friends' | 'couples' | 'office' | 'creators' | 'everyday'

export type Category = {
  id: CategoryId
  label: string
  emoji: string
  situations: string[]
}

export const CATEGORIES: Category[] = [
  {
    id: 'friends',
    label: 'Friends',
    emoji: '🎉',
    situations: [
      'Who pays the bill?',
      'Who gives the next party?',
      'Who drives tonight?',
      'Who orders the food?',
      'Who books the tickets?',
      'Who tells the group the bad news?',
    ],
  },
  {
    id: 'couples',
    label: 'Couples',
    emoji: '💞',
    situations: [
      'Who decides what to eat?',
      'Who makes the tea?',
      'Who picks the movie tonight?',
      'Who plans the next date?',
      'Who apologises first?',
      'Who does the dishes?',
    ],
  },
  {
    id: 'office',
    label: 'Office',
    emoji: '💼',
    situations: [
      'Who presents in the meeting?',
      'Who brings the samosas?',
      'Who takes the client call?',
      'Who writes the standup notes?',
      'Who stays late today?',
      'Who plans the team lunch?',
    ],
  },
  {
    id: 'creators',
    label: 'Content Creators',
    emoji: '🎬',
    situations: [
      'Who edits this video?',
      'Who does the next challenge?',
      'Who goes live tonight?',
      'Who writes the caption?',
      'Who faces the camera first?',
      'Who reads the mean comments?',
    ],
  },
  {
    id: 'everyday',
    label: 'Everyday',
    emoji: '☀️',
    situations: [
      'Who goes to the shop?',
      'Who wakes up early?',
      'Who takes out the trash?',
      'Who feeds the cat?',
      'Who charges the power bank?',
      'Who answers the doorbell?',
    ],
  },
]

export function parseNames(raw: string): string[] {
  return raw
    .split(/[,\n]/)
    .map((n) => n.trim())
    .filter(Boolean)
    .slice(0, 16)
}
